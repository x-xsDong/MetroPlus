#ifndef SECONDWIDGET_H
#define SECONDWIDGET_H

#include <QWidget>
#include "operationtime.h"
#include "historyroute.h"
#include "realtime.h"

namespace Ui {
class secondWidget;
}

class secondWidget : public QWidget
{
    Q_OBJECT

public:
    explicit secondWidget(QWidget *parent = nullptr);
    ~secondWidget();

private slots:
    void on_operationTime_clicked();
    void on_realTime_clicked();
    void on_historyRoute_clicked();

    void receiveRealTime();
    void receiveOperationTime();
    void receivelogin();
    void receiveHistoryRoute();
    void on_changeButton_clicked(bool checked);

    void on_searchButton_clicked();

signals:
    void showOperationTime(); //显示运营时间界面
    void showRealTime();
    void showHistoryRoute();

private:
    Ui::secondWidget *ui;
};

#endif // SECONDWIDGET_H
