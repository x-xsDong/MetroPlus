#include "realtime.h"
#include "ui_realtime.h"

realTime::realTime(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::realTime)
{
    ui->setupUi(this);
}

realTime::~realTime()
{
    delete ui;
}

void realTime::receiveRoutePlanning()
{
    this->show();
}

void realTime::receiveOperationTime()
{
    this->show();
}

void realTime::receiveHistoryRoute()
{
    this->show();
}

void realTime::on_routePlanning_clicked()
{
    this->hide();
    emit showRoutePlanning();
}


void realTime::on_historyRoute_clicked()
{
    this->hide();
    emit showHistoryRoute();
}


void realTime::on_operationTime_clicked()
{
    this->hide();
    emit showOperationTime();
}

