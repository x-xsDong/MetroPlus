#include "secondwidget.h"
#include "ui_secondwidget.h"

#include <QWebEngineView>
#include <QMessageBox>

secondWidget::secondWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::secondWidget)
{
    ui->setupUi(this);
    ui->mapWidget->load(QUrl(":/new/prefix1/mymap.html"));
}

secondWidget::~secondWidget()
{
    delete ui;
}

void secondWidget::on_operationTime_clicked()
{
    this->hide();
    emit showOperationTime();
}

void secondWidget::receiveRealTime()
{
    this->show();
}

void secondWidget::receiveOperationTime()
{
    this->show();
}

void secondWidget::receivelogin()
{
    this->show();
}

void secondWidget::receiveHistoryRoute()
{
    this->show();
}

void secondWidget::on_changeButton_clicked(bool checked)
{
    QString a = ui->startText->text();
    QString b = ui->endText->text();
    ui->startText->setText(b);
    ui->endText->setText(a);
}


void secondWidget::on_realTime_clicked()
{
    this->hide();
    emit showRealTime();
}


void secondWidget::on_historyRoute_clicked()
{
    this->hide();
    emit showHistoryRoute();
}


void secondWidget::on_searchButton_clicked()
{
    QString search = ui->searchText->text();

}

