#include "historyroute.h"
#include "ui_historyroute.h"

historyRoute::historyRoute(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::historyRoute)
{
    ui->setupUi(this);
}

historyRoute::~historyRoute()
{
    delete ui;
}

void historyRoute::on_routePlanning_clicked()
{
    this->hide();
    emit showRoutePlanning();
}

void historyRoute::receiveRoutePlanning()
{
    this->show();
}

void historyRoute::receiveRealTime()
{
    this->show();
}

void historyRoute::receiveOperationTime()
{
    this->show();
}


void historyRoute::on_realTime_clicked()
{
    this->hide();
    emit showRealTime();
}


void historyRoute::on_operationTime_clicked()
{
    this->hide();
    emit showOperationTime();
}

