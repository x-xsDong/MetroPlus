#ifndef OPERATIONTIME_H
#define OPERATIONTIME_H

#include <QWidget>
#include <qwindowdefs.h>

namespace Ui {
class operationTime;
}

class operationTime : public QWidget
{
    Q_OBJECT

public:
    explicit operationTime(QWidget *parent = nullptr);
    ~operationTime();

private slots:
    void on_routePlanning_clicked();
    void on_realTime_clicked();
    void on_historyRoute_clicked();
    void receiveRoutePlanning();
    void receiveHistoryRoute();
    void receiveRealTime();

signals:
    void showRoutePlanning(); //显示路线规划界面
    void showHistoryRoute();
    void showRealTime();

private:
    Ui::operationTime *ui;
};

#endif // OPERATIONTIME_H
