#include "operationtime.h"
#include "ui_operationtime.h"

operationTime::operationTime(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::operationTime)
{
    ui->setupUi(this);
}

operationTime::~operationTime()
{
    delete ui;
}


void operationTime::on_routePlanning_clicked()
{
    this->hide();
    emit showRoutePlanning();
}

void operationTime::receiveRoutePlanning(){
    this->show();
}

void operationTime::receiveHistoryRoute()
{
    this->show();
}

void operationTime::receiveRealTime()
{
    this->show();
}

void operationTime::on_realTime_clicked()
{
    this->hide();
    emit showRealTime();
}


void operationTime::on_historyRoute_clicked()
{
    this->hide();
    emit showHistoryRoute();
}

