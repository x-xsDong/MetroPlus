#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    secondWidget s;
    operationTime o;
    historyRoute h;
    realTime r;
    w.show();
    QObject::connect(&w,SIGNAL(showRoutePlanning()),&s,SLOT(receivelogin()));

    QObject::connect(&h,SIGNAL(showRoutePlanning()),&s,SLOT(receiveHistoryRoute()));
    QObject::connect(&h,SIGNAL(showRealTime()),&r,SLOT(receiveHistoryRoute()));
    QObject::connect(&h,SIGNAL(showOperationTime()),&o,SLOT(receiveHistoryRoute()));

    QObject::connect(&o,SIGNAL(showRoutePlanning()),&s,SLOT(receiveOperationTime()));
    QObject::connect(&o,SIGNAL(showHistoryRoute()),&h,SLOT(receiveOperationTime()));
    QObject::connect(&o,SIGNAL(showRealTime()),&r,SLOT(receiveOperationTime()));

    QObject::connect(&s,SIGNAL(showOperationTime()),&o,SLOT(receiveRoutePlanning()));
    QObject::connect(&s,SIGNAL(showHistoryRoute()),&h,SLOT(receiveRoutePlanning()));
    QObject::connect(&s,SIGNAL(showRealTime()),&r,SLOT(receiveRoutePlanning()));

    QObject::connect(&r,SIGNAL(showOperationTime()),&o,SLOT(receiveRealTime()));
    QObject::connect(&r,SIGNAL(showRoutePlanning()),&s,SLOT(receiveRealTime()));
    QObject::connect(&r,SIGNAL(showHistoryRoute()),&h,SLOT(receiveRealTime()));
    return a.exec();
}
