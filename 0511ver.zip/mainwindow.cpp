#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_login_clicked()
{
    QString user, password;
    qDebug("push button is click");
    user=ui->user->text(); //获取帐号框的内容
    password=ui->password->text();

    if(user=="1" && password=="1"){
        QMessageBox:: information(this,"提示","登录成功");

        this->hide(); //关闭当前界面
        emit showRoutePlanning();
    }
    else{
        QMessageBox::information(this,"提示","登录失败");
    }
}
